# Generated from MGprogramming.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,57,202,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,1,0,1,0,1,0,4,0,36,8,0,11,0,12,0,37,1,0,1,0,
        1,1,1,1,1,1,1,1,1,1,1,1,3,1,48,8,1,1,2,1,2,1,2,1,2,1,2,5,2,55,8,
        2,10,2,12,2,58,9,2,1,2,1,2,1,2,1,3,1,3,1,3,1,3,3,3,67,8,3,1,3,1,
        3,1,3,1,3,1,3,1,3,1,4,1,4,1,4,1,4,1,4,5,4,80,8,4,10,4,12,4,83,9,
        4,1,5,1,5,1,5,1,5,1,5,1,5,4,5,91,8,5,11,5,12,5,92,1,6,1,6,1,6,1,
        6,1,6,1,6,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,8,1,
        8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,
        9,1,10,1,10,4,10,133,8,10,11,10,12,10,134,1,11,1,11,1,11,1,11,1,
        12,1,12,1,12,1,12,1,12,1,12,5,12,147,8,12,10,12,12,12,150,9,12,3,
        12,152,8,12,1,12,1,12,1,12,1,13,1,13,1,13,1,13,5,13,161,8,13,10,
        13,12,13,164,9,13,1,13,1,13,1,14,1,14,5,14,170,8,14,10,14,12,14,
        173,9,14,1,14,1,14,1,15,1,15,1,15,1,15,1,15,1,15,3,15,183,8,15,1,
        15,1,15,1,15,1,15,1,15,1,15,3,15,191,8,15,5,15,193,8,15,10,15,12,
        15,196,9,15,3,15,198,8,15,1,15,1,15,1,15,0,0,16,0,2,4,6,8,10,12,
        14,16,18,20,22,24,26,28,30,0,3,1,0,48,50,1,0,9,13,2,0,48,48,50,50,
        215,0,35,1,0,0,0,2,47,1,0,0,0,4,49,1,0,0,0,6,62,1,0,0,0,8,74,1,0,
        0,0,10,90,1,0,0,0,12,94,1,0,0,0,14,100,1,0,0,0,16,112,1,0,0,0,18,
        122,1,0,0,0,20,132,1,0,0,0,22,136,1,0,0,0,24,140,1,0,0,0,26,156,
        1,0,0,0,28,167,1,0,0,0,30,176,1,0,0,0,32,36,3,4,2,0,33,36,3,6,3,
        0,34,36,3,2,1,0,35,32,1,0,0,0,35,33,1,0,0,0,35,34,1,0,0,0,36,37,
        1,0,0,0,37,35,1,0,0,0,37,38,1,0,0,0,38,39,1,0,0,0,39,40,5,0,0,1,
        40,1,1,0,0,0,41,48,3,12,6,0,42,48,3,14,7,0,43,48,3,16,8,0,44,48,
        3,18,9,0,45,48,3,22,11,0,46,48,3,24,12,0,47,41,1,0,0,0,47,42,1,0,
        0,0,47,43,1,0,0,0,47,44,1,0,0,0,47,45,1,0,0,0,47,46,1,0,0,0,48,3,
        1,0,0,0,49,50,5,18,0,0,50,51,5,49,0,0,51,56,5,19,0,0,52,55,3,6,3,
        0,53,55,3,2,1,0,54,52,1,0,0,0,54,53,1,0,0,0,55,58,1,0,0,0,56,54,
        1,0,0,0,56,57,1,0,0,0,57,59,1,0,0,0,58,56,1,0,0,0,59,60,5,20,0,0,
        60,61,5,15,0,0,61,5,1,0,0,0,62,63,5,31,0,0,63,64,5,49,0,0,64,66,
        5,51,0,0,65,67,3,8,4,0,66,65,1,0,0,0,66,67,1,0,0,0,67,68,1,0,0,0,
        68,69,5,52,0,0,69,70,5,16,0,0,70,71,3,10,5,0,71,72,5,17,0,0,72,73,
        5,15,0,0,73,7,1,0,0,0,74,75,5,45,0,0,75,81,5,49,0,0,76,77,5,1,0,
        0,77,78,5,45,0,0,78,80,5,49,0,0,79,76,1,0,0,0,80,83,1,0,0,0,81,79,
        1,0,0,0,81,82,1,0,0,0,82,9,1,0,0,0,83,81,1,0,0,0,84,91,3,12,6,0,
        85,91,3,14,7,0,86,91,3,16,8,0,87,91,3,18,9,0,88,91,3,22,11,0,89,
        91,3,24,12,0,90,84,1,0,0,0,90,85,1,0,0,0,90,86,1,0,0,0,90,87,1,0,
        0,0,90,88,1,0,0,0,90,89,1,0,0,0,91,92,1,0,0,0,92,90,1,0,0,0,92,93,
        1,0,0,0,93,11,1,0,0,0,94,95,5,45,0,0,95,96,5,49,0,0,96,97,5,2,0,
        0,97,98,7,0,0,0,98,99,5,15,0,0,99,13,1,0,0,0,100,101,5,26,0,0,101,
        102,5,49,0,0,102,103,5,27,0,0,103,104,5,48,0,0,104,105,5,28,0,0,
        105,106,5,48,0,0,106,107,5,29,0,0,107,108,5,48,0,0,108,109,5,51,
        0,0,109,110,3,20,10,0,110,111,5,52,0,0,111,15,1,0,0,0,112,113,5,
        30,0,0,113,114,5,51,0,0,114,115,5,49,0,0,115,116,7,1,0,0,116,117,
        7,2,0,0,117,118,5,52,0,0,118,119,5,21,0,0,119,120,3,20,10,0,120,
        121,5,22,0,0,121,17,1,0,0,0,122,123,5,23,0,0,123,124,5,51,0,0,124,
        125,5,49,0,0,125,126,5,52,0,0,126,127,5,21,0,0,127,128,3,20,10,0,
        128,129,5,22,0,0,129,19,1,0,0,0,130,133,3,2,1,0,131,133,3,24,12,
        0,132,130,1,0,0,0,132,131,1,0,0,0,133,134,1,0,0,0,134,132,1,0,0,
        0,134,135,1,0,0,0,135,21,1,0,0,0,136,137,5,32,0,0,137,138,7,0,0,
        0,138,139,5,15,0,0,139,23,1,0,0,0,140,141,5,31,0,0,141,142,5,49,
        0,0,142,151,5,51,0,0,143,148,5,49,0,0,144,145,5,1,0,0,145,147,5,
        49,0,0,146,144,1,0,0,0,147,150,1,0,0,0,148,146,1,0,0,0,148,149,1,
        0,0,0,149,152,1,0,0,0,150,148,1,0,0,0,151,143,1,0,0,0,151,152,1,
        0,0,0,152,153,1,0,0,0,153,154,5,52,0,0,154,155,5,15,0,0,155,25,1,
        0,0,0,156,157,5,53,0,0,157,162,7,2,0,0,158,159,5,1,0,0,159,161,7,
        2,0,0,160,158,1,0,0,0,161,164,1,0,0,0,162,160,1,0,0,0,162,163,1,
        0,0,0,163,165,1,0,0,0,164,162,1,0,0,0,165,166,5,54,0,0,166,27,1,
        0,0,0,167,171,5,53,0,0,168,170,3,26,13,0,169,168,1,0,0,0,170,173,
        1,0,0,0,171,169,1,0,0,0,171,172,1,0,0,0,172,174,1,0,0,0,173,171,
        1,0,0,0,174,175,5,54,0,0,175,29,1,0,0,0,176,197,5,55,0,0,177,178,
        5,49,0,0,178,182,5,6,0,0,179,183,5,50,0,0,180,183,5,48,0,0,181,183,
        3,26,13,0,182,179,1,0,0,0,182,180,1,0,0,0,182,181,1,0,0,0,183,194,
        1,0,0,0,184,185,5,1,0,0,185,186,5,49,0,0,186,190,5,6,0,0,187,191,
        5,50,0,0,188,191,5,48,0,0,189,191,3,26,13,0,190,187,1,0,0,0,190,
        188,1,0,0,0,190,189,1,0,0,0,191,193,1,0,0,0,192,184,1,0,0,0,193,
        196,1,0,0,0,194,192,1,0,0,0,194,195,1,0,0,0,195,198,1,0,0,0,196,
        194,1,0,0,0,197,177,1,0,0,0,197,198,1,0,0,0,198,199,1,0,0,0,199,
        200,5,56,0,0,200,31,1,0,0,0,19,35,37,47,54,56,66,81,90,92,132,134,
        148,151,162,171,182,190,194,197
    ]

class MGprogrammingParser ( Parser ):

    grammarFileName = "MGprogramming.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "','", "'todorhoiloh'", "'+'", "'-'", 
                     "'*'", "':'", "'^'", "'|'", "'>'", "'<'", "'>='", "'<='", 
                     "'='", "'=/='", "'\\n'", "'ehleh'", "'duusgah'", "'angi'", 
                     "'ehleh_angi'", "'duusgah_angi'", "'ehleh_davtalt'", 
                     "'duusgah_davtalt'", "'zuur'", "'urgeljleh'", "'zavsar'", 
                     "'d'", "'aas'", "'tuld'", "'nii tuld'", "'hervee'", 
                     "'ner'", "'butsah'", "'hevleh'", "'orolt'", "'buhel'", 
                     "'urt'", "'butarhai'", "'ih_butarhai'", "'temdegt'", 
                     "'mor'", "'tiim_ugui'", "'jagsaalt'", "'bagts'", "'buleg'", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'('", "')'", "'['", "']'", 
                     "'{'", "'}'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "ASSIGN_VALUE", "PLUS", 
                      "MINUS", "MULTIPLY", "DIVIDE", "POWER", "MODULO", 
                      "GREATER_THAN", "LESSER_THAN", "GREATER_OR_EQUAL", 
                      "LESSER_OR_EQUAL", "EQUAL", "NOT_EQUAL", "NEW_LINE", 
                      "START_FUNCTION", "END_FUNCTION", "CLASS_DEF", "START_CLASS", 
                      "END_CLASS", "START_LOOP", "END_LOOP", "WHILE", "CONTINUE", 
                      "BREAK", "FOR", "FOR_FROM", "FOR_TO", "FOR_JUMP", 
                      "IF", "FUNCT_NAME", "RETURN", "PRINT", "INPUT", "INT", 
                      "LONG", "FLOAT", "DOUBLE", "CHAR", "STRING", "BOOLEAN", 
                      "LIST", "SET", "DICT", "VAR_TYPE", "COMMENT", "START_LONG_COMMENT", 
                      "NUMBER", "VARIABLE", "STRING_LITERAL", "OPEN_BRACKET", 
                      "CLOSE_BRACKET", "OPEN_LIST_BRACKET", "CLOSE_LIST_BRACKET", 
                      "DICT_OPEN_BRACKET", "DICT_CLOSE_BRACKET", "WS" ]

    RULE_program = 0
    RULE_statement = 1
    RULE_class_def = 2
    RULE_function_def = 3
    RULE_args = 4
    RULE_function_body = 5
    RULE_assign = 6
    RULE_for_loop = 7
    RULE_if_stmt = 8
    RULE_while_loop = 9
    RULE_loop_body = 10
    RULE_return_stmt = 11
    RULE_function_call = 12
    RULE_array = 13
    RULE_table = 14
    RULE_dictionary = 15

    ruleNames =  [ "program", "statement", "class_def", "function_def", 
                   "args", "function_body", "assign", "for_loop", "if_stmt", 
                   "while_loop", "loop_body", "return_stmt", "function_call", 
                   "array", "table", "dictionary" ]

    EOF = Token.EOF
    T__0=1
    ASSIGN_VALUE=2
    PLUS=3
    MINUS=4
    MULTIPLY=5
    DIVIDE=6
    POWER=7
    MODULO=8
    GREATER_THAN=9
    LESSER_THAN=10
    GREATER_OR_EQUAL=11
    LESSER_OR_EQUAL=12
    EQUAL=13
    NOT_EQUAL=14
    NEW_LINE=15
    START_FUNCTION=16
    END_FUNCTION=17
    CLASS_DEF=18
    START_CLASS=19
    END_CLASS=20
    START_LOOP=21
    END_LOOP=22
    WHILE=23
    CONTINUE=24
    BREAK=25
    FOR=26
    FOR_FROM=27
    FOR_TO=28
    FOR_JUMP=29
    IF=30
    FUNCT_NAME=31
    RETURN=32
    PRINT=33
    INPUT=34
    INT=35
    LONG=36
    FLOAT=37
    DOUBLE=38
    CHAR=39
    STRING=40
    BOOLEAN=41
    LIST=42
    SET=43
    DICT=44
    VAR_TYPE=45
    COMMENT=46
    START_LONG_COMMENT=47
    NUMBER=48
    VARIABLE=49
    STRING_LITERAL=50
    OPEN_BRACKET=51
    CLOSE_BRACKET=52
    OPEN_LIST_BRACKET=53
    CLOSE_LIST_BRACKET=54
    DICT_OPEN_BRACKET=55
    DICT_CLOSE_BRACKET=56
    WS=57

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(MGprogrammingParser.EOF, 0)

        def class_def(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.Class_defContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.Class_defContext,i)


        def function_def(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.Function_defContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.Function_defContext,i)


        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.StatementContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.StatementContext,i)


        def getRuleIndex(self):
            return MGprogrammingParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)




    def program(self):

        localctx = MGprogrammingParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 35 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 35
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                if la_ == 1:
                    self.state = 32
                    self.class_def()
                    pass

                elif la_ == 2:
                    self.state = 33
                    self.function_def()
                    pass

                elif la_ == 3:
                    self.state = 34
                    self.statement()
                    pass


                self.state = 37 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 35191964041216) != 0)):
                    break

            self.state = 39
            self.match(MGprogrammingParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assign(self):
            return self.getTypedRuleContext(MGprogrammingParser.AssignContext,0)


        def for_loop(self):
            return self.getTypedRuleContext(MGprogrammingParser.For_loopContext,0)


        def if_stmt(self):
            return self.getTypedRuleContext(MGprogrammingParser.If_stmtContext,0)


        def while_loop(self):
            return self.getTypedRuleContext(MGprogrammingParser.While_loopContext,0)


        def return_stmt(self):
            return self.getTypedRuleContext(MGprogrammingParser.Return_stmtContext,0)


        def function_call(self):
            return self.getTypedRuleContext(MGprogrammingParser.Function_callContext,0)


        def getRuleIndex(self):
            return MGprogrammingParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)




    def statement(self):

        localctx = MGprogrammingParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statement)
        try:
            self.state = 47
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [45]:
                self.enterOuterAlt(localctx, 1)
                self.state = 41
                self.assign()
                pass
            elif token in [26]:
                self.enterOuterAlt(localctx, 2)
                self.state = 42
                self.for_loop()
                pass
            elif token in [30]:
                self.enterOuterAlt(localctx, 3)
                self.state = 43
                self.if_stmt()
                pass
            elif token in [23]:
                self.enterOuterAlt(localctx, 4)
                self.state = 44
                self.while_loop()
                pass
            elif token in [32]:
                self.enterOuterAlt(localctx, 5)
                self.state = 45
                self.return_stmt()
                pass
            elif token in [31]:
                self.enterOuterAlt(localctx, 6)
                self.state = 46
                self.function_call()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Class_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CLASS_DEF(self):
            return self.getToken(MGprogrammingParser.CLASS_DEF, 0)

        def VARIABLE(self):
            return self.getToken(MGprogrammingParser.VARIABLE, 0)

        def START_CLASS(self):
            return self.getToken(MGprogrammingParser.START_CLASS, 0)

        def END_CLASS(self):
            return self.getToken(MGprogrammingParser.END_CLASS, 0)

        def NEW_LINE(self):
            return self.getToken(MGprogrammingParser.NEW_LINE, 0)

        def function_def(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.Function_defContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.Function_defContext,i)


        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.StatementContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.StatementContext,i)


        def getRuleIndex(self):
            return MGprogrammingParser.RULE_class_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClass_def" ):
                listener.enterClass_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClass_def" ):
                listener.exitClass_def(self)




    def class_def(self):

        localctx = MGprogrammingParser.Class_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_class_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 49
            self.match(MGprogrammingParser.CLASS_DEF)
            self.state = 50
            self.match(MGprogrammingParser.VARIABLE)
            self.state = 51
            self.match(MGprogrammingParser.START_CLASS)
            self.state = 56
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 35191963779072) != 0):
                self.state = 54
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
                if la_ == 1:
                    self.state = 52
                    self.function_def()
                    pass

                elif la_ == 2:
                    self.state = 53
                    self.statement()
                    pass


                self.state = 58
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 59
            self.match(MGprogrammingParser.END_CLASS)
            self.state = 60
            self.match(MGprogrammingParser.NEW_LINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FUNCT_NAME(self):
            return self.getToken(MGprogrammingParser.FUNCT_NAME, 0)

        def VARIABLE(self):
            return self.getToken(MGprogrammingParser.VARIABLE, 0)

        def OPEN_BRACKET(self):
            return self.getToken(MGprogrammingParser.OPEN_BRACKET, 0)

        def CLOSE_BRACKET(self):
            return self.getToken(MGprogrammingParser.CLOSE_BRACKET, 0)

        def START_FUNCTION(self):
            return self.getToken(MGprogrammingParser.START_FUNCTION, 0)

        def function_body(self):
            return self.getTypedRuleContext(MGprogrammingParser.Function_bodyContext,0)


        def END_FUNCTION(self):
            return self.getToken(MGprogrammingParser.END_FUNCTION, 0)

        def NEW_LINE(self):
            return self.getToken(MGprogrammingParser.NEW_LINE, 0)

        def args(self):
            return self.getTypedRuleContext(MGprogrammingParser.ArgsContext,0)


        def getRuleIndex(self):
            return MGprogrammingParser.RULE_function_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_def" ):
                listener.enterFunction_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_def" ):
                listener.exitFunction_def(self)




    def function_def(self):

        localctx = MGprogrammingParser.Function_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_function_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 62
            self.match(MGprogrammingParser.FUNCT_NAME)
            self.state = 63
            self.match(MGprogrammingParser.VARIABLE)
            self.state = 64
            self.match(MGprogrammingParser.OPEN_BRACKET)
            self.state = 66
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==45:
                self.state = 65
                self.args()


            self.state = 68
            self.match(MGprogrammingParser.CLOSE_BRACKET)
            self.state = 69
            self.match(MGprogrammingParser.START_FUNCTION)
            self.state = 70
            self.function_body()
            self.state = 71
            self.match(MGprogrammingParser.END_FUNCTION)
            self.state = 72
            self.match(MGprogrammingParser.NEW_LINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VAR_TYPE(self, i:int=None):
            if i is None:
                return self.getTokens(MGprogrammingParser.VAR_TYPE)
            else:
                return self.getToken(MGprogrammingParser.VAR_TYPE, i)

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(MGprogrammingParser.VARIABLE)
            else:
                return self.getToken(MGprogrammingParser.VARIABLE, i)

        def getRuleIndex(self):
            return MGprogrammingParser.RULE_args

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgs" ):
                listener.enterArgs(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgs" ):
                listener.exitArgs(self)




    def args(self):

        localctx = MGprogrammingParser.ArgsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_args)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 74
            self.match(MGprogrammingParser.VAR_TYPE)
            self.state = 75
            self.match(MGprogrammingParser.VARIABLE)
            self.state = 81
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1:
                self.state = 76
                self.match(MGprogrammingParser.T__0)
                self.state = 77
                self.match(MGprogrammingParser.VAR_TYPE)
                self.state = 78
                self.match(MGprogrammingParser.VARIABLE)
                self.state = 83
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assign(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.AssignContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.AssignContext,i)


        def for_loop(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.For_loopContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.For_loopContext,i)


        def if_stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.If_stmtContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.If_stmtContext,i)


        def while_loop(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.While_loopContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.While_loopContext,i)


        def return_stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.Return_stmtContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.Return_stmtContext,i)


        def function_call(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.Function_callContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.Function_callContext,i)


        def getRuleIndex(self):
            return MGprogrammingParser.RULE_function_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_body" ):
                listener.enterFunction_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_body" ):
                listener.exitFunction_body(self)




    def function_body(self):

        localctx = MGprogrammingParser.Function_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_function_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 90 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 90
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [45]:
                    self.state = 84
                    self.assign()
                    pass
                elif token in [26]:
                    self.state = 85
                    self.for_loop()
                    pass
                elif token in [30]:
                    self.state = 86
                    self.if_stmt()
                    pass
                elif token in [23]:
                    self.state = 87
                    self.while_loop()
                    pass
                elif token in [32]:
                    self.state = 88
                    self.return_stmt()
                    pass
                elif token in [31]:
                    self.state = 89
                    self.function_call()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 92 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 35191963779072) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VAR_TYPE(self):
            return self.getToken(MGprogrammingParser.VAR_TYPE, 0)

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(MGprogrammingParser.VARIABLE)
            else:
                return self.getToken(MGprogrammingParser.VARIABLE, i)

        def ASSIGN_VALUE(self):
            return self.getToken(MGprogrammingParser.ASSIGN_VALUE, 0)

        def NEW_LINE(self):
            return self.getToken(MGprogrammingParser.NEW_LINE, 0)

        def NUMBER(self):
            return self.getToken(MGprogrammingParser.NUMBER, 0)

        def STRING_LITERAL(self):
            return self.getToken(MGprogrammingParser.STRING_LITERAL, 0)

        def getRuleIndex(self):
            return MGprogrammingParser.RULE_assign

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssign" ):
                listener.enterAssign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssign" ):
                listener.exitAssign(self)




    def assign(self):

        localctx = MGprogrammingParser.AssignContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_assign)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 94
            self.match(MGprogrammingParser.VAR_TYPE)
            self.state = 95
            self.match(MGprogrammingParser.VARIABLE)
            self.state = 96
            self.match(MGprogrammingParser.ASSIGN_VALUE)
            self.state = 97
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1970324836974592) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 98
            self.match(MGprogrammingParser.NEW_LINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class For_loopContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(MGprogrammingParser.FOR, 0)

        def VARIABLE(self):
            return self.getToken(MGprogrammingParser.VARIABLE, 0)

        def FOR_FROM(self):
            return self.getToken(MGprogrammingParser.FOR_FROM, 0)

        def NUMBER(self, i:int=None):
            if i is None:
                return self.getTokens(MGprogrammingParser.NUMBER)
            else:
                return self.getToken(MGprogrammingParser.NUMBER, i)

        def FOR_TO(self):
            return self.getToken(MGprogrammingParser.FOR_TO, 0)

        def FOR_JUMP(self):
            return self.getToken(MGprogrammingParser.FOR_JUMP, 0)

        def OPEN_BRACKET(self):
            return self.getToken(MGprogrammingParser.OPEN_BRACKET, 0)

        def loop_body(self):
            return self.getTypedRuleContext(MGprogrammingParser.Loop_bodyContext,0)


        def CLOSE_BRACKET(self):
            return self.getToken(MGprogrammingParser.CLOSE_BRACKET, 0)

        def getRuleIndex(self):
            return MGprogrammingParser.RULE_for_loop

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFor_loop" ):
                listener.enterFor_loop(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFor_loop" ):
                listener.exitFor_loop(self)




    def for_loop(self):

        localctx = MGprogrammingParser.For_loopContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_for_loop)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 100
            self.match(MGprogrammingParser.FOR)
            self.state = 101
            self.match(MGprogrammingParser.VARIABLE)
            self.state = 102
            self.match(MGprogrammingParser.FOR_FROM)
            self.state = 103
            self.match(MGprogrammingParser.NUMBER)
            self.state = 104
            self.match(MGprogrammingParser.FOR_TO)
            self.state = 105
            self.match(MGprogrammingParser.NUMBER)
            self.state = 106
            self.match(MGprogrammingParser.FOR_JUMP)
            self.state = 107
            self.match(MGprogrammingParser.NUMBER)
            self.state = 108
            self.match(MGprogrammingParser.OPEN_BRACKET)
            self.state = 109
            self.loop_body()
            self.state = 110
            self.match(MGprogrammingParser.CLOSE_BRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class If_stmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(MGprogrammingParser.IF, 0)

        def OPEN_BRACKET(self):
            return self.getToken(MGprogrammingParser.OPEN_BRACKET, 0)

        def VARIABLE(self):
            return self.getToken(MGprogrammingParser.VARIABLE, 0)

        def CLOSE_BRACKET(self):
            return self.getToken(MGprogrammingParser.CLOSE_BRACKET, 0)

        def START_LOOP(self):
            return self.getToken(MGprogrammingParser.START_LOOP, 0)

        def loop_body(self):
            return self.getTypedRuleContext(MGprogrammingParser.Loop_bodyContext,0)


        def END_LOOP(self):
            return self.getToken(MGprogrammingParser.END_LOOP, 0)

        def EQUAL(self):
            return self.getToken(MGprogrammingParser.EQUAL, 0)

        def GREATER_THAN(self):
            return self.getToken(MGprogrammingParser.GREATER_THAN, 0)

        def LESSER_THAN(self):
            return self.getToken(MGprogrammingParser.LESSER_THAN, 0)

        def GREATER_OR_EQUAL(self):
            return self.getToken(MGprogrammingParser.GREATER_OR_EQUAL, 0)

        def LESSER_OR_EQUAL(self):
            return self.getToken(MGprogrammingParser.LESSER_OR_EQUAL, 0)

        def NUMBER(self):
            return self.getToken(MGprogrammingParser.NUMBER, 0)

        def STRING_LITERAL(self):
            return self.getToken(MGprogrammingParser.STRING_LITERAL, 0)

        def getRuleIndex(self):
            return MGprogrammingParser.RULE_if_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIf_stmt" ):
                listener.enterIf_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIf_stmt" ):
                listener.exitIf_stmt(self)




    def if_stmt(self):

        localctx = MGprogrammingParser.If_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_if_stmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 112
            self.match(MGprogrammingParser.IF)
            self.state = 113
            self.match(MGprogrammingParser.OPEN_BRACKET)
            self.state = 114
            self.match(MGprogrammingParser.VARIABLE)
            self.state = 115
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 15872) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 116
            _la = self._input.LA(1)
            if not(_la==48 or _la==50):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 117
            self.match(MGprogrammingParser.CLOSE_BRACKET)
            self.state = 118
            self.match(MGprogrammingParser.START_LOOP)
            self.state = 119
            self.loop_body()
            self.state = 120
            self.match(MGprogrammingParser.END_LOOP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class While_loopContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHILE(self):
            return self.getToken(MGprogrammingParser.WHILE, 0)

        def OPEN_BRACKET(self):
            return self.getToken(MGprogrammingParser.OPEN_BRACKET, 0)

        def VARIABLE(self):
            return self.getToken(MGprogrammingParser.VARIABLE, 0)

        def CLOSE_BRACKET(self):
            return self.getToken(MGprogrammingParser.CLOSE_BRACKET, 0)

        def START_LOOP(self):
            return self.getToken(MGprogrammingParser.START_LOOP, 0)

        def loop_body(self):
            return self.getTypedRuleContext(MGprogrammingParser.Loop_bodyContext,0)


        def END_LOOP(self):
            return self.getToken(MGprogrammingParser.END_LOOP, 0)

        def getRuleIndex(self):
            return MGprogrammingParser.RULE_while_loop

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhile_loop" ):
                listener.enterWhile_loop(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhile_loop" ):
                listener.exitWhile_loop(self)




    def while_loop(self):

        localctx = MGprogrammingParser.While_loopContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_while_loop)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 122
            self.match(MGprogrammingParser.WHILE)
            self.state = 123
            self.match(MGprogrammingParser.OPEN_BRACKET)
            self.state = 124
            self.match(MGprogrammingParser.VARIABLE)
            self.state = 125
            self.match(MGprogrammingParser.CLOSE_BRACKET)
            self.state = 126
            self.match(MGprogrammingParser.START_LOOP)
            self.state = 127
            self.loop_body()
            self.state = 128
            self.match(MGprogrammingParser.END_LOOP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Loop_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.StatementContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.StatementContext,i)


        def function_call(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.Function_callContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.Function_callContext,i)


        def getRuleIndex(self):
            return MGprogrammingParser.RULE_loop_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLoop_body" ):
                listener.enterLoop_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLoop_body" ):
                listener.exitLoop_body(self)




    def loop_body(self):

        localctx = MGprogrammingParser.Loop_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_loop_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 132 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 132
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
                if la_ == 1:
                    self.state = 130
                    self.statement()
                    pass

                elif la_ == 2:
                    self.state = 131
                    self.function_call()
                    pass


                self.state = 134 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 35191963779072) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Return_stmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(MGprogrammingParser.RETURN, 0)

        def NEW_LINE(self):
            return self.getToken(MGprogrammingParser.NEW_LINE, 0)

        def VARIABLE(self):
            return self.getToken(MGprogrammingParser.VARIABLE, 0)

        def NUMBER(self):
            return self.getToken(MGprogrammingParser.NUMBER, 0)

        def STRING_LITERAL(self):
            return self.getToken(MGprogrammingParser.STRING_LITERAL, 0)

        def getRuleIndex(self):
            return MGprogrammingParser.RULE_return_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReturn_stmt" ):
                listener.enterReturn_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReturn_stmt" ):
                listener.exitReturn_stmt(self)




    def return_stmt(self):

        localctx = MGprogrammingParser.Return_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_return_stmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 136
            self.match(MGprogrammingParser.RETURN)
            self.state = 137
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1970324836974592) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 138
            self.match(MGprogrammingParser.NEW_LINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_callContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FUNCT_NAME(self):
            return self.getToken(MGprogrammingParser.FUNCT_NAME, 0)

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(MGprogrammingParser.VARIABLE)
            else:
                return self.getToken(MGprogrammingParser.VARIABLE, i)

        def OPEN_BRACKET(self):
            return self.getToken(MGprogrammingParser.OPEN_BRACKET, 0)

        def CLOSE_BRACKET(self):
            return self.getToken(MGprogrammingParser.CLOSE_BRACKET, 0)

        def NEW_LINE(self):
            return self.getToken(MGprogrammingParser.NEW_LINE, 0)

        def getRuleIndex(self):
            return MGprogrammingParser.RULE_function_call

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_call" ):
                listener.enterFunction_call(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_call" ):
                listener.exitFunction_call(self)




    def function_call(self):

        localctx = MGprogrammingParser.Function_callContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_function_call)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 140
            self.match(MGprogrammingParser.FUNCT_NAME)
            self.state = 141
            self.match(MGprogrammingParser.VARIABLE)
            self.state = 142
            self.match(MGprogrammingParser.OPEN_BRACKET)
            self.state = 151
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==49:
                self.state = 143
                self.match(MGprogrammingParser.VARIABLE)
                self.state = 148
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==1:
                    self.state = 144
                    self.match(MGprogrammingParser.T__0)
                    self.state = 145
                    self.match(MGprogrammingParser.VARIABLE)
                    self.state = 150
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 153
            self.match(MGprogrammingParser.CLOSE_BRACKET)
            self.state = 154
            self.match(MGprogrammingParser.NEW_LINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArrayContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPEN_LIST_BRACKET(self):
            return self.getToken(MGprogrammingParser.OPEN_LIST_BRACKET, 0)

        def CLOSE_LIST_BRACKET(self):
            return self.getToken(MGprogrammingParser.CLOSE_LIST_BRACKET, 0)

        def STRING_LITERAL(self, i:int=None):
            if i is None:
                return self.getTokens(MGprogrammingParser.STRING_LITERAL)
            else:
                return self.getToken(MGprogrammingParser.STRING_LITERAL, i)

        def NUMBER(self, i:int=None):
            if i is None:
                return self.getTokens(MGprogrammingParser.NUMBER)
            else:
                return self.getToken(MGprogrammingParser.NUMBER, i)

        def getRuleIndex(self):
            return MGprogrammingParser.RULE_array

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArray" ):
                listener.enterArray(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArray" ):
                listener.exitArray(self)




    def array(self):

        localctx = MGprogrammingParser.ArrayContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_array)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 156
            self.match(MGprogrammingParser.OPEN_LIST_BRACKET)
            self.state = 157
            _la = self._input.LA(1)
            if not(_la==48 or _la==50):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 162
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1:
                self.state = 158
                self.match(MGprogrammingParser.T__0)
                self.state = 159
                _la = self._input.LA(1)
                if not(_la==48 or _la==50):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 164
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 165
            self.match(MGprogrammingParser.CLOSE_LIST_BRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPEN_LIST_BRACKET(self):
            return self.getToken(MGprogrammingParser.OPEN_LIST_BRACKET, 0)

        def CLOSE_LIST_BRACKET(self):
            return self.getToken(MGprogrammingParser.CLOSE_LIST_BRACKET, 0)

        def array(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.ArrayContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.ArrayContext,i)


        def getRuleIndex(self):
            return MGprogrammingParser.RULE_table

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTable" ):
                listener.enterTable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTable" ):
                listener.exitTable(self)




    def table(self):

        localctx = MGprogrammingParser.TableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_table)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 167
            self.match(MGprogrammingParser.OPEN_LIST_BRACKET)
            self.state = 171
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==53:
                self.state = 168
                self.array()
                self.state = 173
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 174
            self.match(MGprogrammingParser.CLOSE_LIST_BRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DictionaryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DICT_OPEN_BRACKET(self):
            return self.getToken(MGprogrammingParser.DICT_OPEN_BRACKET, 0)

        def DICT_CLOSE_BRACKET(self):
            return self.getToken(MGprogrammingParser.DICT_CLOSE_BRACKET, 0)

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(MGprogrammingParser.VARIABLE)
            else:
                return self.getToken(MGprogrammingParser.VARIABLE, i)

        def DIVIDE(self, i:int=None):
            if i is None:
                return self.getTokens(MGprogrammingParser.DIVIDE)
            else:
                return self.getToken(MGprogrammingParser.DIVIDE, i)

        def STRING_LITERAL(self, i:int=None):
            if i is None:
                return self.getTokens(MGprogrammingParser.STRING_LITERAL)
            else:
                return self.getToken(MGprogrammingParser.STRING_LITERAL, i)

        def NUMBER(self, i:int=None):
            if i is None:
                return self.getTokens(MGprogrammingParser.NUMBER)
            else:
                return self.getToken(MGprogrammingParser.NUMBER, i)

        def array(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MGprogrammingParser.ArrayContext)
            else:
                return self.getTypedRuleContext(MGprogrammingParser.ArrayContext,i)


        def getRuleIndex(self):
            return MGprogrammingParser.RULE_dictionary

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDictionary" ):
                listener.enterDictionary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDictionary" ):
                listener.exitDictionary(self)




    def dictionary(self):

        localctx = MGprogrammingParser.DictionaryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_dictionary)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 176
            self.match(MGprogrammingParser.DICT_OPEN_BRACKET)
            self.state = 197
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==49:
                self.state = 177
                self.match(MGprogrammingParser.VARIABLE)
                self.state = 178
                self.match(MGprogrammingParser.DIVIDE)
                self.state = 182
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [50]:
                    self.state = 179
                    self.match(MGprogrammingParser.STRING_LITERAL)
                    pass
                elif token in [48]:
                    self.state = 180
                    self.match(MGprogrammingParser.NUMBER)
                    pass
                elif token in [53]:
                    self.state = 181
                    self.array()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 194
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==1:
                    self.state = 184
                    self.match(MGprogrammingParser.T__0)
                    self.state = 185
                    self.match(MGprogrammingParser.VARIABLE)
                    self.state = 186
                    self.match(MGprogrammingParser.DIVIDE)
                    self.state = 190
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [50]:
                        self.state = 187
                        self.match(MGprogrammingParser.STRING_LITERAL)
                        pass
                    elif token in [48]:
                        self.state = 188
                        self.match(MGprogrammingParser.NUMBER)
                        pass
                    elif token in [53]:
                        self.state = 189
                        self.array()
                        pass
                    else:
                        raise NoViableAltException(self)

                    self.state = 196
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 199
            self.match(MGprogrammingParser.DICT_CLOSE_BRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





